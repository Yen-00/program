import numpy as np
import math

# Student ID = 2561586
# d1 = 6
# d2 = 8
# k = 4
# shift = -2
# rows_keep = 2


def read_oscillatory_wave_data(filename):
    data = np.genfromtxt(filename, delimiter=",", skip_header=1)
    lengths = data[:, 0]
    amplitudes = data[:, 1]

    mean_amp = np.mean(amplitudes)
    max_amp = np.max(amplitudes)

    print("Original amplitudes:", amplitudes)
    print("Mean amplitude:", mean_amp)
    print("Max amplitude:", max_amp)

    return lengths, amplitudes


def read_standing_wave_data(filename):
    data = np.genfromtxt(filename, delimiter=",", skip_header=1)
    lengths = data[:, 0]
    tensions = data[:, 1]

    speeds = np.sqrt(tensions / 1)

    print("\nOriginal tensions:", tensions)
    print("Wave speeds:", speeds)

    return lengths, tensions, speeds


def main():
    d1 = 6
    d2 = 8
    k = (d1 + d2) % 4 + 2
    shift = d1 - d2
    rows_keep = (d1 % 2) + 2

    osc_file = "oscillatory_2561586.csv"
    stand_file = "standing_2561586.csv"

    # Component A
    lengths1, amplitudes = read_oscillatory_wave_data(osc_file)
    lengths2, tensions, speeds = read_standing_wave_data(stand_file)

    # Component B

    # Oscillatory modification
    new_amplitudes = amplitudes + shift
    new_mean = np.mean(new_amplitudes)
    new_max = np.max(new_amplitudes)

    print("\nShifted amplitudes:", new_amplitudes)
    print("New mean amplitude:", new_mean)
    print("New max amplitude:", new_max)

    # Standing wave modification
    new_tensions = tensions * k
    new_speeds = np.sqrt(new_tensions / 1)

    print("\nScaled tensions:", new_tensions)
    print("New wave speeds:", new_speeds)


if __name__ == "__main__":
    main()